<?php
if(isset($_POST['submit']))
{
	 #extract($_FILES);
 echo "<pre>";
	  print_r($_POST);
	 print_r($_FILES);
	 echo "First Name : ".$_POST["fname"]."<br>";
	  echo "Last Name : ".$_POST["lname"]."<br>";
	  echo "Address : ".$_POST["address"]."<br>";
	  echo "Mobile Number : ".$_POST["mobile"]."<br>";
	  echo "Guide number: ".$_POST["mobile-number"]."<br>";
	  echo "Year : ".$_POST["Year"]."<br>";
	  echo "Branch : ".$_POST["branch"]."<br>";
	  echo "No of members : ".$_POST["mem"]."<br>";
	  echo "Project type : ".$_POST["tech"]."<br>";
	  echo "Abstract : ".$_FILES["file"]['name']."<br>";
	  echo "Problem Statement : ".$_FILES["file1"]['name']."<br>";
	  echo "PPT : ".$_FILES["file2"]['name']."<br>";
	  echo "Review1 : ".$_FILES["file3"]['name']."<br>";

	 echo "Review2 : ".$_FILES["file4"]['name']."<br>";
	  echo "Review3 : ".$_FILES["file5"]['name']."<br>";
	  echo "Code : ".$_FILES["file6"]['name']."<br>";
	  
	$name = $_POST["fname"];
	 
	  include 'database.php';

	 $conn = OpenCon();
	 $name=$_POST["fname"];
	 if($conn){
	 	echo "Connected Successfully";
	 }
	 else{
	 	echo "Connection Failure";
	 }
	 
// 	/*$sql = "CREATE TABLE {$name}(
// 	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
// 	firstname VARCHAR(255) NOT NULL,
// 	lastname VARCHAR(255) NOT NULL,
// 	year INT(6),
// 	address VARCHAR(255),
// 	branch VARCHAR(255),
// 	team_members INT(6),
// 	guide_name VARCHAR(255),
// 	guide_phoneno INT(10),
// 	type_of_project VARCHAR(255),
// 	abstract varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	problem varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	ppt varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	review1 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	review2 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	review3 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	code varchar(255) COLLATE utf8_unicode_ci NOT NULL,
// 	reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
// 	)";*/

 	$firstname =$_POST["fname"];//1
	 $lastname =$_POST["lname"];//2
	 $mobile=$_POST["mobile"];
	 $year=$_POST["Year"];//3
	 $address=$_POST["address"];//4
	 $branch=$_POST["branch"];//5
	 $gname=$_POST["Gname"];//6
	 $members=$_POST["mem"];//7
	 $gmobile=$_POST["mobile-number"];//8
	 $tech=$_POST["tech"];//9
	 $abstract=$_FILES["file"]['name'];//10
	 $problem=$_FILES["file1"]['name'];//11
	 $ppt=$_FILES["file2"]['name'];//12
	 $review1=$_FILES["file3"]['name'];//13
	 $review2=$_FILES["file4"]['name'];//14
	 $review3=$_FILES["file5"]['name'];//15
	 $code=$_FILES["file6"]['name'];//16
	 echo "$mobile <br> $gmobile";
// 	// if ($conn->query($sql) === TRUE) {
//  //  		echo "Table $name created successfully";
// 	// } else {
// 	//   		echo "Error creating table: " . $conn->error;
// 	// }
		$pp = "practice\\".$name."\\";

		 mkdir($pp, 0700);
		 $targetDir = $pp;
		 $fileName = basename($_FILES["file"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
	
         move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
		 $fileName = basename($_FILES["file1"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
	
         move_uploaded_file($_FILES["file1"]["tmp_name"], $targetFilePath);
         $fileName = basename($_FILES["file2"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
         move_uploaded_file($_FILES["file2"]["tmp_name"], $targetFilePath);
        $fileName = basename($_FILES["file3"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
         move_uploaded_file($_FILES["file3"]["tmp_name"], $targetFilePath);
         $fileName = basename($_FILES["file4"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
         move_uploaded_file($_FILES["file4"]["tmp_name"], $targetFilePath);
         $fileName = basename($_FILES["file5"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
         move_uploaded_file($_FILES["file5"]["tmp_name"], $targetFilePath);
         $fileName = basename($_FILES["file6"]["name"]);
		 $targetFilePath = $targetDir . $fileName;
		 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
         move_uploaded_file($_FILES["file6"]["tmp_name"], $targetFilePath);
	
	$sql = "INSERT INTO tbl_register (firstname, lastname,mobile, year, address, branch, teammembers, guidename, guidephone, typeofproject,abstract,problem,ppt,review1,review2,review3,code)
	VALUES ('$firstname','$lastname','$mobile','$year','$address','$branch','$members','$gname','$gmobile','$tech','$abstract','$problem','$ppt','$review1','$review2','$review3','$code')";
	
if ($conn->query($sql) === TRUE) {
  echo "Text Record created successfully <br>";
} else {
  echo "Error creating database: " . $conn->error;
}
            echo $pp."<br>";
	CloseCon($conn);
	//  if(!empty($abstract))
	//  {
	//  	$path = 'practice/';
	//  	$abstract_file1 = time()."_".$abstract;
	//  	$abstract_tmp = $_FILES['file']['tmp_name'];
	//  	$move_upload = move_uploaded_file($abstract_tmp,$path.$abstract_file1);
	//  	if($move_upload > 0)
	//  	{
	//  		$abstract_file = $path.$abstract_file1;
	//  	}
	//  }
	//  if(!empty($problem))
	//  {
	//  	$path = 'practice/';
	//  	$problem_file1 = time()."_".$problem;
	//  	$problem_tmp = $_FILES['file1']['tmp_name'];
	//  	$move_upload = move_uploaded_file($problem_tmp,$path.$problem_file1);
	//  	if($move_upload > 0)
	//  	{
	//  		$problem_file = $path.$problem_file1;
	//  	}
	//  }
	//  // exit;
	// $conn = mysqli_connect("localhost","root","","practice");
	// if(!$conn)
	// {
	// 	die('Connection Failed'.mysqli_connect_error());
	// }
	
	// $sql = "INSERT INTO tbl_register (`firstname`,`abstract`,`problem`) VALUES ('$firstname','$abstract_file','problem_file')";
	// $result = mysqli_query($conn,$sql);
	// // echo "<pre>";
	// // print_r($result);
	// // exit;
	// if($result > 0)
	// {
	// 	echo "Successfully";
	// }
	// else
	// {
	// 	echo "Failed";
	// }
}
?>
